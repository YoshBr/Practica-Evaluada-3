/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.practico.pkg3;

import javax.swing.JOptionPane;

/**
 *
 * @author bryan
 */
public class VentasSemana {
    // Atributos
    private int[][] ventas; // Matriz de ventas (7 dias x N productos)
    private Producto[] productos; // Vector para productos

    // Creamos el constructor
    public VentasSemana(int numProductos) {
        ventas = new int[7][numProductos]; // 7 dias, N productos
        productos = new Producto[numProductos];
        ingresarNombresProductos();
        ingresarVentas();
    }

    // Metodo para ingresar los nombres de los productos
    private void ingresarNombresProductos() {
        for (int i = 0; i < productos.length; i++) {
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto " + (i + 1) + ":");
            productos[i] = new Producto(nombre);
        }
    }

    // Metodo para ingresar las ventas de la semana
    private void ingresarVentas() {
        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        for (int i = 0; i < ventas.length; i++) {
            for (int j = 0; j < ventas[i].length; j++) {
                String input = JOptionPane.showInputDialog(
                    "Ingrese las ventas de " + productos[j].getNombre() + " para el día " + dias[i] + ":"
                );
                ventas[i][j] = Integer.parseInt(input);
            }
        }
    }

    // Metodo para calcular el total de toda las ventas por producto
    public int[] calcularTotalVentasPorProducto() {
        int[] totales = new int[productos.length];
        for (int j = 0; j < ventas[0].length; j++) {
            for (int i = 0; i < ventas.length; i++) {
                totales[j] += ventas[i][j];
            }
        }
        return totales;
    }

    // Metodo para czlcular el dia con mayores ventas totales
    public int calcularDiaConMayoresVentas() {
        int diaMayor = 0;
        int maxVentas = 0;
        for (int i = 0; i < ventas.length; i++) {
            int totalDia = 0;
            for (int j = 0; j < ventas[i].length; j++) {
                totalDia += ventas[i][j];
            }
            if (totalDia > maxVentas) {
                maxVentas = totalDia;
                diaMayor = i;
            }
        }
        return diaMayor;
    }

    // Metodo para encontrar el producto que mas se vendido
    public int encontrarProductoMasVendido() {
        int[] totales = calcularTotalVentasPorProducto();
        int indiceMasVendido = 0;
        for (int i = 1; i < totales.length; i++) {
            if (totales[i] > totales[indiceMasVendido]) {
                indiceMasVendido = i;
            }
        }
        return indiceMasVendido;
    }

    // Metodo para mostrar los resultados
    public void mostrarResultados() {
        int[] totales = calcularTotalVentasPorProducto();
        int diaMayor = calcularDiaConMayoresVentas();
        int productoMasVendido = encontrarProductoMasVendido();

        // Mostramos el total de todas las ventas por producto
        System.out.println("Total de ventas por producto:");
        for (int i = 0; i < productos.length; i++) {
            System.out.println(productos[i].getNombre() + ": " + totales[i]);
        }

        // Mostramos el dia con mayores ventas
        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        System.out.println("El día con mayores ventas totales es: " + dias[diaMayor] + " (con un total de " + maxVentas(diaMayor) + " ventas)");

        // Mostramos el producto ma22s vendido
        System.out.println("El producto más vendido es: " + productos[productoMasVendido].getNombre() + ", con " + totales[productoMasVendido] + " unidades.");
    }

    // Metodo secundario para calcular el total de ventas de un dia especifico
    private int maxVentas(int dia) {
        int total = 0;
        for (int j = 0; j < ventas[dia].length; j++) {
            total += ventas[dia][j];
        }
        return total;
    }
}