/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.practico.pkg3;

/**
 *
 * @author bryan
 */
public class Producto {
    // Atributos
    private String nombre;

    // Creamos el constructor
    public Producto(String nombre) {
        this.nombre = nombre;
    }

    // Creamos los getter y Setter
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
