/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.practico.pkg3;

import javax.swing.JOptionPane;

/**
 *
 * @author bryan
 */
public class EjercicioPractico3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Solicitamos el numero de productos
        int numProductos = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de productos:"));

        // Creamos la instancia VentasSemana
        VentasSemana ventasSemana = new VentasSemana(numProductos);

        // Mostramos los resultados
        ventasSemana.mostrarResultados();
    }
}